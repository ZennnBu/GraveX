package me.gravex;

import java.util.List;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class GraveCommand implements CommandExecutor {
    private final GraveX plugin;
    private final GraveManager manager;
    public GraveCommand(GraveX plugin, GraveManager manager) { this.plugin = plugin; this.manager = manager; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            sender.sendMessage(ChatColor.GOLD + "GraveX commands: /gravex locate, /gravex list, /gravex reload");
            return true;
        }
        if (args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("gravex.admin")) { sender.sendMessage(ChatColor.RED + "No permission."); return true; }
            plugin.reloadConfig();
            sender.sendMessage(ChatColor.GREEN + "GraveX config reloaded.");
            return true;
        }
        if (!(sender instanceof Player p)) { sender.sendMessage("Players only."); return true; }
        if (args[0].equalsIgnoreCase("locate")) {
            List<GraveData> graves = manager.forOwner(p.getUniqueId());
            if (graves.isEmpty()) { p.sendMessage(ChatColor.RED + "You have no graves."); return true; }
            GraveData g = graves.get(graves.size() - 1);
            Location l = g.getLocation();
            p.sendMessage(ChatColor.GOLD + "Latest grave: " + l.getWorld().getName() + " " + l.getBlockX() + ", " + l.getBlockY() + ", " + l.getBlockZ());
            return true;
        }
        if (args[0].equalsIgnoreCase("list")) {
            List<GraveData> graves = manager.forOwner(p.getUniqueId());
            p.sendMessage(ChatColor.GOLD + "Your graves: " + graves.size());
            for (GraveData g : graves) {
                Location l = g.getLocation();
                p.sendMessage(ChatColor.YELLOW + l.getWorld().getName() + " " + l.getBlockX() + ", " + l.getBlockY() + ", " + l.getBlockZ());
            }
            return true;
        }
        p.sendMessage(ChatColor.RED + "Unknown subcommand. Use /gravex help.");
        return true;
    }
}
