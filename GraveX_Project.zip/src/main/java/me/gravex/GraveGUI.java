package me.gravex;

import java.util.*;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;

public final class GraveGUI {
    private GraveGUI() {}

    public static void open(GraveX plugin, GraveManager manager, Player player, GraveData grave) {
        ItemStack[] items = grave.getContents();
        Inventory inv = Bukkit.createInventory(null, 54, ChatColor.DARK_GRAY + "Grave of " + grave.getOwnerName());
        int slot = 0;
        for (ItemStack item : items) {
            if (item != null && !item.getType().isAir() && slot < 54) inv.setItem(slot++, item.clone());
        }
        player.openInventory(inv);
        plugin.getServer().getPluginManager().registerEvents(new GraveGUIListener(plugin, manager, grave, inv), plugin);
    }

    static class GraveGUIListener implements Listener {
        private final GraveX plugin;
        private final GraveManager manager;
        private final GraveData grave;
        private final Inventory inventory;
        GraveGUIListener(GraveX plugin, GraveManager manager, GraveData grave, Inventory inventory) {
            this.plugin = plugin; this.manager = manager; this.grave = grave; this.inventory = inventory;
        }
        @EventHandler
        public void onClick(InventoryClickEvent e) {
            if (!e.getView().getTopInventory().equals(inventory)) return;
            e.setCancelled(true);
            if (!(e.getWhoClicked() instanceof Player p)) return;
            if (e.getClickedInventory() == null || e.getClickedInventory() != inventory) return;
            ItemStack clicked = e.getCurrentItem();
            if (clicked == null || clicked.getType().isAir()) return;
            p.getInventory().addItem(clicked.clone()).values().forEach(item -> p.getWorld().dropItemNaturally(p.getLocation(), item));
            e.getInventory().setItem(e.getSlot(), null);
            ItemStack[] updated = new ItemStack[54];
            for (int i = 0; i < 54; i++) updated[i] = inventory.getItem(i);
            grave.getContents(); // contents are refreshed below via a copy
            // Persist remaining contents by replacing the grave data entry.
            manager.updateContents(grave, updated);
            if (inventoryIsEmpty(inventory)) {
                p.closeInventory();
                manager.remove(grave);
                p.sendMessage(ChatColor.GREEN + "GraveX: Grave emptied and removed.");
            }
        }
        @EventHandler
        public void onClose(InventoryCloseEvent e) {
            if (e.getInventory().equals(inventory)) HandlerList.unregisterAll(this);
        }
        private boolean inventoryIsEmpty(Inventory inv) {
            for (ItemStack item : inv.getContents()) if (item != null && !item.getType().isAir()) return false;
            return true;
        }
    }
}
