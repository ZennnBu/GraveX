package me.gravex;
import org.bukkit.plugin.java.JavaPlugin;
public final class GraveX extends JavaPlugin {
 private GraveManager manager;
 @Override public void onEnable(){ saveDefaultConfig(); manager=new GraveManager(this); getServer().getPluginManager().registerEvents(new GraveListener(this,manager),this); getServer().getPluginManager().registerEvents(new GraveGUIListener(this,manager),this); getCommand("gravex").setExecutor(new GraveCommand(this,manager)); getLogger().info("GraveX enabled"); }
 @Override public void onDisable(){ if(manager!=null) manager.save(); }
 public GraveManager manager(){ return manager; }
}
