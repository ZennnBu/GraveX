package me.gravex;

import org.bukkit.plugin.java.JavaPlugin;

public final class GraveX extends JavaPlugin {
    private GraveManager graveManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        graveManager = new GraveManager(this);
        getServer().getPluginManager().registerEvents(new GraveListener(this, graveManager), this);
        getCommand("gravex").setExecutor(new GraveCommand(this, graveManager));
        getLogger().info("GraveX enabled!");
    }

    @Override
    public void onDisable() {
        if (graveManager != null) graveManager.save();
    }

    public GraveManager getGraveManager() {
        return graveManager;
    }
}
