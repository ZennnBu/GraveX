package me.gravex;
import java.util.UUID; import org.bukkit.Location; import org.bukkit.inventory.ItemStack;
public class GraveData {
 private final UUID id,owner; private final String ownerName; private final Location location; private final long expiresAt; private ItemStack[] contents;
 public GraveData(UUID id,UUID owner,String ownerName,Location location,long expiresAt,ItemStack[] contents){this.id=id;this.owner=owner;this.ownerName=ownerName;this.location=location;this.expiresAt=expiresAt;setContents(contents);}
 public UUID getId(){return id;} public UUID getOwner(){return owner;} public String getOwnerName(){return ownerName;} public Location getLocation(){return location;} public long getExpiresAt(){return expiresAt;} public ItemStack[] getContents(){return contents.clone();} public void setContents(ItemStack[] items){contents=items==null?new ItemStack[0]:items.clone();} public boolean expired(){return System.currentTimeMillis()>=expiresAt;}
}
