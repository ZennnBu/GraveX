package me.gravex;

import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.inventory.ItemStack;

public class GraveData {
    private final UUID id;
    private final UUID owner;
    private final String ownerName;
    private final Location location;
    private final long expiresAt;
    private ItemStack[] contents;

    public GraveData(UUID id, UUID owner, String ownerName, Location location, long expiresAt, ItemStack[] contents) {
        this.id = id;
        this.owner = owner;
        this.ownerName = ownerName;
        this.location = location;
        this.expiresAt = expiresAt;
        this.contents = contents;
    }

    public UUID getId() { return id; }
    public UUID getOwner() { return owner; }
    public String getOwnerName() { return ownerName; }
    public Location getLocation() { return location; }
    public long getExpiresAt() { return expiresAt; }
    public ItemStack[] getContents() { return contents; }
    public void setContents(ItemStack[] contents) { this.contents = contents; }
    public boolean isExpired() { return System.currentTimeMillis() >= expiresAt; }
}
