package me.gravex;

import java.io.File;
import java.io.IOException;
import java.util.*;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

public class GraveManager {
    private final GraveX plugin;
    private final Map<UUID, GraveData> graves = new LinkedHashMap<>();
    private final File file;

    public GraveManager(GraveX plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "graves.yml");
        load();
    }

    public Collection<GraveData> all() { return Collections.unmodifiableCollection(graves.values()); }
    public GraveData getAt(Location loc) {
        if (loc == null) return null;
        for (GraveData g : graves.values()) {
            Location l = g.getLocation();
            if (l.getWorld().equals(loc.getWorld()) && l.getBlockX() == loc.getBlockX()
                    && l.getBlockY() == loc.getBlockY() && l.getBlockZ() == loc.getBlockZ()) return g;
        }
        return null;
    }
    public List<GraveData> forOwner(UUID owner) {
        List<GraveData> list = new ArrayList<>();
        for (GraveData g : graves.values()) if (g.getOwner().equals(owner)) list.add(g);
        list.sort(Comparator.comparingLong(GraveData::getExpiresAt));
        return list;
    }
    public void add(GraveData g) { graves.put(g.getId(), g); save(); }
    public void updateContents(GraveData g, ItemStack[] contents) { g.setContents(contents); save(); }
    public void remove(GraveData g) {
        graves.remove(g.getId());
        Block b = g.getLocation().getBlock();
        if (b.getType() == Material.BARREL) b.setType(Material.AIR);
        save();
    }
    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (GraveData g : graves.values()) {
            String key = g.getId().toString();
            y.set(key + ".owner", g.getOwner().toString());
            y.set(key + ".owner-name", g.getOwnerName());
            y.set(key + ".world", g.getLocation().getWorld().getName());
            y.set(key + ".x", g.getLocation().getX());
            y.set(key + ".y", g.getLocation().getY());
            y.set(key + ".z", g.getLocation().getZ());
            y.set(key + ".expires", g.getExpiresAt());
            y.set(key + ".items", g.getContents());
        }
        try { y.save(file); } catch (IOException e) { plugin.getLogger().severe("Could not save graves: " + e.getMessage()); }
    }
    private void load() {
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        for (String key : y.getKeys(false)) {
            try {
                UUID id = UUID.fromString(key);
                UUID owner = UUID.fromString(y.getString(key + ".owner"));
                World w = Bukkit.getWorld(y.getString(key + ".world"));
                if (w == null) continue;
                Location loc = new Location(w, y.getDouble(key + ".x"), y.getDouble(key + ".y"), y.getDouble(key + ".z"));
                ItemStack[] items = (ItemStack[]) y.get(key + ".items");
                if (items == null) items = new ItemStack[0];
                GraveData data = new GraveData(id, owner, y.getString(key + ".owner-name", "Unknown"), loc,
                        y.getLong(key + ".expires"), items);
                graves.put(id, data);
            } catch (Exception ex) { plugin.getLogger().warning("Skipped invalid grave entry " + key); }
        }
    }
}
