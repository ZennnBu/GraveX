package me.gravex;

import java.util.*;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public class GraveListener implements Listener {
    private final GraveX plugin;
    private final GraveManager manager;

    public GraveListener(GraveX plugin, GraveManager manager) {
        this.plugin = plugin;
        this.manager = manager;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(PlayerDeathEvent event) {
        Player p = event.getEntity();
        if (p.getLocation().getWorld() == null) return;
        List<ItemStack> stored = new ArrayList<>();
        for (ItemStack item : event.getDrops()) if (item != null && !item.getType().isAir()) stored.add(item.clone());
        ItemStack[] armor = p.getInventory().getArmorContents();
        for (ItemStack item : armor) if (item != null && !item.getType().isAir()) stored.add(item.clone());
        ItemStack offhand = p.getInventory().getItemInOffHand();
        if (offhand != null && !offhand.getType().isAir()) stored.add(offhand.clone());
        if (stored.isEmpty()) return;

        Location loc = p.getLocation().getBlock().getLocation();
        if (plugin.getConfig().getBoolean("grave.create-barrel", true)) {
            Block block = loc.getBlock();
            if (!block.getType().isAir() && block.getType() != Material.BARREL) {
                loc = loc.clone().add(0, 1, 0);
                if (!loc.getBlock().getType().isAir()) loc = loc.clone().add(0, 1, 0);
            }
            loc.getBlock().setType(Material.BARREL);
        }
        event.getDrops().clear();
        p.getInventory().clear();
        p.getInventory().setArmorContents(new ItemStack[4]);
        p.getInventory().setItemInOffHand(null);

        int minutes = Math.max(1, plugin.getConfig().getInt("grave.lifetime-minutes", 30));
        GraveData grave = new GraveData(UUID.randomUUID(), p.getUniqueId(), p.getName(), loc,
                System.currentTimeMillis() + minutes * 60_000L, stored.toArray(new ItemStack[0]));
        manager.add(grave);
        p.sendMessage(color("&6[GraveX] &aYour grave has been created! &7Location: &f" + loc.getBlockX() + ", " + loc.getBlockY() + ", " + loc.getBlockZ()));
        if (plugin.getConfig().getBoolean("grave.sound", true)) p.playSound(p.getLocation(), Sound.BLOCK_BARREL_OPEN, 0.8f, 1.0f);
        if (plugin.getConfig().getBoolean("grave.particles", true)) loc.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, loc.clone().add(0.5, 1, 0.5), 12, 0.3, 0.5, 0.3);
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK || event.getClickedBlock() == null) return;
        GraveData grave = manager.getAt(event.getClickedBlock().getLocation());
        if (grave == null) return;
        event.setCancelled(true);
        Player p = event.getPlayer();
        if (plugin.getConfig().getBoolean("grave.owner-only", true) && !grave.getOwner().equals(p.getUniqueId()) && !p.hasPermission("gravex.admin")) {
            p.sendMessage(color("&cThis grave belongs to &f" + grave.getOwnerName() + "&c."));
            return;
        }
        GraveGUI.open(plugin, manager, p, grave);
    }

    private String color(String s) { return ChatColor.translateAlternateColorCodes('&', s); }
}
